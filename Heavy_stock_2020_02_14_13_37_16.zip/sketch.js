function setup() {
  createCanvas(windowWidth, windowHeight);
  
    background(200, 80, 255);
}

function draw() {
  circle(mouseX, mouseY, mouseY/3);

}